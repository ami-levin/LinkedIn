------------------------------------
-- LinkedIn Learning ---------------
-- Advanced SQL - Query Processing -
-- Ami Levin 2020 ------------------
-- .\Chapter1\Video4.sql -----------
------------------------------------

-- Animal Shelter demo database used for this course
-- https://github.com/ami-levin/LinkedIn/tree/master/Query%20Processing/Demo%20Database

-- Animal Shelter generic repository for contributions and feedback
-- https://github.com/ami-levin/Animal_Shelter
